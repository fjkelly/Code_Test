﻿
/*********************************************
 * Author: Frank Kelly
 * DealerOn Code Test Problem One
 * Mars Rovers
 * 
 * This program reads input through the console and provides the current output based on the specifications given.
 * It prevents the robot from moving outside of the boundaries, and can be used with multiple rovers.
 * ******************************************/
using System;
using System.Collections.Generic;
namespace DealerOn_Code_Test
{
    class Program
    {

        // The main method calls the MarsRovers method and reads the input from the console until the user enters nothing.
        // Inputs are case sensitive and it's sensitive to spaces. This could be improved.
        static void Main(string[] args)
        {
            List<String> myList = new List<string>();
            String consoleInput;

            // The user must press enter twice on the last entry to signal the end. I did not add an exit keyword.
            while ((consoleInput = Console.ReadLine()) != "")
            {
                myList.Add(consoleInput);
            }

            myList = MarsRovers(myList);

            foreach (String element in myList)
            {
                Console.WriteLine(element);
            }

        }

        // This method parses the strings to find the integers for the boundaries and current rover position
        // The instructions are sent to the other method to keep the code more organized and readable.
        // Input is not validated
        public static List<String> MarsRovers(List<String> input)
        {
            int horizBound = -1;
            int vertBound = -1;
            int currentHoriz = -1;
            int currentVert = -1;
            char orientation = '?';

            char[] directions;
            char[] inputChars;
            int counter = 0;
            List<String> output = new List<String>();
            

            // Parses the string to find the boundaries, current position, and orientation
            foreach (String element in input)
            {
                inputChars = element.ToCharArray();
               
                    if (counter == 0)
                {
                    
                        horizBound = Int32.Parse(inputChars[0].ToString());
                        vertBound = Int32.Parse(inputChars[2].ToString());
           
                }
                else if (counter % 2 != 0)
                {

                    currentHoriz = Int32.Parse(inputChars[0].ToString());
                    currentVert = Int32.Parse(inputChars[2].ToString());
                    orientation = inputChars[4];
                }
                
                //Calls the ExecuteInstructions method where the robot movement occurs and from which the output is returned.
                else
                {
                    directions = element.ToCharArray();
                    output.Add(ExecuteInstructions(horizBound, vertBound, currentHoriz, currentVert, orientation, directions));
                }
                counter++;
            }


            return output;

        }

        //This method converts the current orientation into a number to easily be incremented or decremented when turning
        //It checks to avoid exiting the boundaries before moving
        // Inputs are case sensitive, this could be improved in future work.
        private static String ExecuteInstructions(int horizBound, int vertBound, int currentHoriz, int currentVert, char orientation, char[] directions)
        {
            int orientNum = 0;

            switch (orientation)
            {
                case 'N':
                    orientNum = 0;
                    break;

                case 'E':
                    orientNum = 1;
                    break;

                case 'S':
                    orientNum = 2;
                    break;

                case 'W':
                    orientNum = 3;
                    break;

                
            }


            foreach (char c in directions)
            {
                switch (c)
                {
                    case 'L':
                        orientNum -= 1;
                        break;

                    case 'R':
                        orientNum += 1;
                        break;

                    //It checks to avoid exiting the stated boundaries.
                    case 'M':
                        switch (orientNum)
                        {
                            case 0:
                                if (currentVert < vertBound)
                                    currentVert++;
                                break;

                            case 1:
                                if (currentHoriz < horizBound)
                                    currentHoriz++;
                                break;

                            case 2:
                                if (currentVert > 0)
                                    currentVert--;
                                break;

                            case 3:
                                if (currentHoriz > 0)
                                    currentHoriz--;
                                break;

                        }
                        break;

                   
                }
                if (orientNum > 3)
                {
                    orientNum -= 4;
                }
                else if (orientNum < 0)
                {
                    orientNum += 4;
                }

                // This is my least favorite part since I converted the character to an int, then back to a character.
                // Ideally I should find a more elegant solution.
                switch (orientNum)
                {
                    case 0:
                        orientation = 'N';
                        break;

                    case 1:
                        orientation = 'E';
                        break;

                    case 2:
                        orientation = 'S';
                        break;

                    case 3:
                        orientation = 'W';
                        break;
                }

            }

            //returns the correct format
            return $"{currentHoriz} {currentVert} {orientation}";
        }
    }
}
