using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace Unit_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            List<String> inputStrs = new List<String>();
            List<String> expectedOutput = new List<string>();
            



            inputStrs.Add("5 5");
            inputStrs.Add("1 2 N");
            inputStrs.Add("LMLMLMLMM");
            inputStrs.Add("3 3 E");
            inputStrs.Add("MMRMMRMRRM");

            expectedOutput.Add("1 3 N");
            expectedOutput.Add("5 1 E");


            //Assert.AreEqual();
        }
    }
}
